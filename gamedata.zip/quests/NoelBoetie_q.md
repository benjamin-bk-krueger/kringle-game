```
Logic Chompers! Complete a stage in Potpourri at Intermediate or higher to get a special achievement!

Controls:
Arrow keys or WASD: Move Chompy
Enter or Space: Chomp the current expression
Click: Navigate to adjacent squares and chomp the square Chompy's in
Esc: Pause the game
i: Toggle text and iconography
```
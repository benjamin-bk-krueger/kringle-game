* grep man page: https://man7.org/linux/man-pages/man1/grep.1p.html
* Regular Expressions tutorial: https://regexland.com/regex-tutorial/